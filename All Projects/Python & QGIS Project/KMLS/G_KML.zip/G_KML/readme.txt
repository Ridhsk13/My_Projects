This folder contains project report named "Project Phase-1 Report.pdf" 
and KML file named "Section_G.kml" for UTA map section G.
Mansoor Abbas Ali and Chirag Hareshkumar Shah are members of this team.